re2c lessons, (c) M. Boerger 2006

001_upn_calculator

	This lesson gets you started with re2c. In the end you will have an easy 
	RPN calculator for use at command line.

	You will learn about the basic interface of re2c when scanning input 
	strings. How to detect the end of the input and use that to stop scanning 
	in order to	avoid problems.

	The lesson also contains a windows subdirectory to get you started in the 
	Microsoft world.

002_strip_comments

	In this lesson you will learn how to use multiple scanner blocks and how 
	to read the input from a file instead of a zero terminated string. In the 
	end you will have a scanner that filters comments out of c source files 
	but keeps re2c comments.
