"""
This package contains the Landscape library. Code inside this
package must be generic and self-contained, depending only on
code inside of the package itself or libraries outside
Landscape.
"""
