#define UTS_RELEASE "4.2.0-27-generic"
#define UTS_UBUNTU_RELEASE_ABI 27
